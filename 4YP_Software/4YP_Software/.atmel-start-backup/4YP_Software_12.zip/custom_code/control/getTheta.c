/*
 * getTheta.c
 *
 * Created: 18/01/2021 14:08:16
 *  Author: Ben
 */ 

#include "getTheta.h"

float getThetaHS(){
	//Estimate angle from hall sensors
}
