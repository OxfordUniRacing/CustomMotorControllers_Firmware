/*
 * Initial_Testing.h
 *
 * Created: 10/02/2021 17:32:30
 *  Author: Ruzhev
 */ 


#ifndef INITIAL_TESTING_H_
#define INITIAL_TESTING_H_

void first_slow_spin (void);
void Temp_Initial_Test (void);
void Current_Voltage_Inital_Test (void);
void PWM_Initial_Test (void);
void POS_Sensor_Initial_Test (void);



#endif /* INITIAL_TESTING_H_ */