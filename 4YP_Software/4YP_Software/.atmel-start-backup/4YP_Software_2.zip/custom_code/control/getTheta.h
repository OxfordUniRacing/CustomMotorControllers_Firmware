/*
 * getTheta.h
 *
 * Created: 18/01/2021 14:08:03
 *  Author: Ben
 */ 


#ifndef GETTHETA_H_
#define GETTHETA_H_

float getThetaHS(void);
float getThetaObs(void);



#endif /* GETTHETA_H_ */

